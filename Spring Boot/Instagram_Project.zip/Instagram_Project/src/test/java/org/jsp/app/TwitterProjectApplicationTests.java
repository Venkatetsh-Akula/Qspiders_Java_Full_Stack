package org.jsp.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwitterProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
